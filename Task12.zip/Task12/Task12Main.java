import java.time.*;
public class Task12Main {
    static int pass=0, fail=0;
    static void chk(String n, double exp, double act){ boolean ok=exp==act; if(ok)pass++; else fail++;
        System.out.println(String.format("%-44s expected=%-7s actual=%-7s %s", n, exp, act, ok?"PASS":"FAIL")); }
    public static void main(String[] args) {
        System.out.println("--- Regression: all 15 Task 11 tests on the modified classes ---");
        Task11Main.main(null);
        System.out.println("--- New requirement tests ---");
        LocalDate d = LocalDate.of(2026, 11, 9);
        ParkingSystem s = new ParkingSystem(new int[]{40, 60, 50, 80, 100});
        s.enter(VehicleFactory.create("VAN", "TNV1"), d.atTime(8, 30));
        chk("Van 08:30-11:30 (150)", 150, s.exit("TNV1", d.atTime(11, 30), null, 0));
        s.enter(VehicleFactory.create("EBIKE", "TNE1"), d.atTime(10, 0));
        chk("E-bike 45 min flat fee", 20, s.exit("TNE1", d.atTime(10, 45), null, 0));
        s.enter(VehicleFactory.create("CAR", "TNC1"), d.atTime(9, 0));
        chk("Visitor, valid one-day pass", 0, s.exit("TNC1", d.atTime(12, 0), new OneDayPass(d), 0));
        s.enter(VehicleFactory.create("CAR", "TNC2"), d.atTime(9, 0));
        chk("Car 130 min, no pass", 90, s.exit("TNC2", d.atTime(11, 10), null, 0));
        s.enter(VehicleFactory.create("CAR", "TNC3"), d.atTime(9, 0));
        chk("Car, one-day pass of yesterday (expired)", 30, s.exit("TNC3", d.atTime(10, 0), new OneDayPass(d.minusDays(1)), 0));
        s.enter(VehicleFactory.create("VAN", "TNV2"), d.atTime(16, 30));
        chk("Van 16:30-18:30 (60+30)", 90, s.exit("TNV2", d.atTime(18, 30), null, 0));
        chk("Daily collection (150+20+0+90+30+90)", 380, s.getCollection());
        String msg; try { s.enter(VehicleFactory.create("DRONE", "TND1"), d.atTime(9,0)); msg="accepted"; } catch (RuntimeException e) { msg=e.getMessage(); }
        System.out.println("Unknown type DRONE -> " + msg);
        System.out.println("New tests PASSED=" + pass + " FAILED=" + fail);
    }
}
interface Pass { boolean isValidOn(LocalDate d); }
class MonthlyPass implements Pass { private final YearMonth month; MonthlyPass(YearMonth m){month=m;} public boolean isValidOn(LocalDate d){ return YearMonth.from(d).equals(month);} }
class OneDayPass implements Pass { private final LocalDate day; OneDayPass(LocalDate d){day=d;} public boolean isValidOn(LocalDate d){ return day.equals(d);} }
class EBike extends Vehicle { EBike(String r){super(r);} @Override protected double ratePerHour(){return 0;} @Override public double calculateFee(int minutes){ return 20; } }
class DeliveryVan extends Vehicle {
    DeliveryVan(String r){super(r);} @Override protected double ratePerHour(){return 30;}
    @Override public double calculateFee(LocalDateTime entry, int minutes){
        int hours=(minutes+59)/60; double total=0;
        for(int i=0;i<hours;i++){ int h=entry.plusHours(i).getHour(); total += (h>=9 && h<17) ? 2*ratePerHour() : ratePerHour(); }
        return total; } }
