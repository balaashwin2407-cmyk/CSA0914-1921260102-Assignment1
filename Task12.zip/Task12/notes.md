# Task12: Design Challenge - Re-evaluate and Adapt

Source: Vehicles.java, ParkingFacility.java, ParkingSystem.java, Task11Main.java, Task12Main.java

Run: `javac *.java` then `java Task12Main`

Result: Decision MODIFY. 15 regression tests plus 7 new tests pass; daily collection Rs 380 matches the hand calculation.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
