# Task11: Implement, Test and Defend

Source: Vehicles.java, ParkingFacility.java, ParkingSystem.java, Task11Main.java

Run: `javac *.java` then `java Task11Main`

Result: 15 of 15 tests pass; hand-calculated daily collection Rs 270 equals the program output.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
