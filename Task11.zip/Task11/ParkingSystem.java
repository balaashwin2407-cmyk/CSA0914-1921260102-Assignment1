class ParkingTicket {
    private static int counter = 0;                 // shared by all tickets
    private final int ticketNo;
    private final String regNo;
    private final int floor, slot;
    ParkingTicket(String regNo, int floor, int slot) {
        if (regNo == null || regNo.isBlank()) throw new IllegalArgumentException("regNo required");
        this.ticketNo = ++counter;
        this.regNo = regNo; this.floor = floor; this.slot = slot;
    }
    ParkingTicket(ParkingTicket t) {                // copy constructor: duplicate ticket, same number
        this.ticketNo = t.ticketNo; this.regNo = t.regNo; this.floor = t.floor; this.slot = t.slot;
    }
    int getTicketNo() { return ticketNo; }
    String getRegNo() { return regNo; }
    int getFloor() { return floor; }
    int getSlot() { return slot; }
    @Override public String toString() { return "Ticket#" + ticketNo + "[" + regNo + " F" + floor + " S" + slot + "]"; }
}
class VehicleFactory {
    static Vehicle create(String type, String reg) {
        switch (type.toUpperCase()) {
            case "TWOWHEELER": return new TwoWheeler(reg);
            case "CAR": return new Car(reg);
            case "EV": return new ElectricCar(reg);
            default: throw new IllegalArgumentException("Unknown vehicle type: " + type);
        }
    }
}
class ParkingSystem {
    private final ParkingFacility facility;
    private final java.util.HashMap<String, ParkingTicket> active = new java.util.HashMap<>();
    private final java.util.HashMap<String, Vehicle> vehicles = new java.util.HashMap<>();
    private double collection = 0;
    ParkingSystem(int[] slotsPerFloor) { facility = new ParkingFacility(slotsPerFloor); }
    ParkingTicket enter(Vehicle v) {
        if (active.containsKey(v.getRegNo())) throw new IllegalStateException("Duplicate registration: " + v.getRegNo());
        int[] pos = facility.allocate(v.getRegNo());
        if (pos == null) throw new IllegalStateException("Parking full");
        ParkingTicket t = new ParkingTicket(v.getRegNo(), pos[0], pos[1]);
        active.put(v.getRegNo(), t); vehicles.put(v.getRegNo(), v);
        return t;
    }
    double exit(String regNo, int minutes, boolean hasPass, int kWh) {
        ParkingTicket t = active.get(regNo);
        if (t == null) throw new IllegalStateException("No active ticket for " + regNo);
        Vehicle v = vehicles.get(regNo);
        double fee = hasPass ? 0 : v.calculateFee(minutes);
        if (v instanceof Chargeable c) fee += c.chargingFee(kWh);
        facility.release(t.getFloor(), t.getSlot());
        active.remove(regNo); vehicles.remove(regNo);
        collection += fee;
        return fee;
    }
    double getCollection() { return collection; }
    boolean release(int f, int s) { return facility.release(f, s); }
}
