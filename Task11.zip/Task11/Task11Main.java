public class Task11Main {
    static int pass = 0, fail = 0;
    static void check(String name, Object exp, Object act) {
        boolean ok = exp.equals(act); if (ok) pass++; else fail++;
        System.out.println(String.format("%-34s expected=%-28s actual=%-28s %s", name, exp, act, ok ? "PASS" : "FAIL"));
    }
    static String tryEnter(ParkingSystem s, String type, String reg) {
        try { return s.enter(VehicleFactory.create(type, reg)).toString(); }
        catch (RuntimeException e) { return e.getMessage(); }
    }
    public static void main(String[] args) {
        ParkingSystem s = new ParkingSystem(new int[]{2, 1});
        check("Enter two-wheeler", "Ticket#1[TN01A1 F0 S0]", tryEnter(s, "TwoWheeler", "TN01A1"));
        check("Enter car", "Ticket#2[TN02B2 F0 S1]", tryEnter(s, "Car", "TN02B2"));
        check("Enter EV (last free slot)", "Ticket#3[TN03C3 F1 S0]", tryEnter(s, "EV", "TN03C3"));
        check("Facility full", "Parking full", tryEnter(s, "Car", "TN09Z9"));
        check("Duplicate registration", "Duplicate registration: TN01A1", tryEnter(s, "Car", "TN01A1"));
        check("Unknown vehicle type", "Unknown vehicle type: Hoverboard", tryEnter(s, "Hoverboard", "TN08H8"));
        check("Invalid slot release", false, s.release(7, 0));
        check("Two-wheeler 130 min", 30.0, s.exit("TN01A1", 130, false, 0));
        check("Car 61 min (slab boundary +1)", 60.0, s.exit("TN02B2", 61, false, 0));
        check("EV 90 min + 10 kWh", 180.0, s.exit("TN03C3", 90, false, 10));
        check("Total collection (30+60+180)", 270.0, s.getCollection());
        s.enter(VehicleFactory.create("Car", "TN05E5"));
        check("Zero-minute parking", 0.0, s.exit("TN05E5", 0, false, 0));
        s.enter(VehicleFactory.create("Car", "TN06F6"));
        check("Exactly 60 min", 30.0, s.exit("TN06F6", 60, false, 0));
        s.enter(VehicleFactory.create("Car", "TN07G7"));
        check("Monthly pass holder", 0.0, s.exit("TN07G7", 500, true, 0));
        check("Exit without ticket", "No active ticket for TN00X0", exitMsg(s, "TN00X0"));
        System.out.println("PASSED=" + pass + " FAILED=" + fail);
    }
    static String exitMsg(ParkingSystem s, String r) { try { s.exit(r, 10, false, 0); return "ok"; } catch (RuntimeException e) { return e.getMessage(); } }
}
