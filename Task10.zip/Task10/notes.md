# Task10: Encapsulation, Packages, Wrapper Classes

Source: EncapsulationDemo.java

Run: `javac *.java` then `java EncapsulationDemo`

Result: Validating setter rejects -5; Integer 1000 == 1000 is false but equals() is true.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
