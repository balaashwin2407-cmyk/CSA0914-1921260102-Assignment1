public class EncapsulationDemo {
    static class Stay {
        private int minutes;
        void setMinutes(int m) { if (m < 0) throw new IllegalArgumentException("minutes must be >= 0"); minutes = m; }
        int getMinutes() { return minutes; }
    }
    public static void main(String[] args) {
        Stay s = new Stay(); s.setMinutes(90);
        try { s.setMinutes(-5); } catch (IllegalArgumentException e) { System.out.println("Rejected: " + e.getMessage()); }
        System.out.println("Stored minutes still " + s.getMinutes());
        Integer a = 127, b = 127, c = 1000, d = 1000;
        System.out.println("127 == 127   -> " + (a == b) + "   (cached)");
        System.out.println("1000 == 1000 -> " + (c == d) + "  (different objects)");
        System.out.println("1000.equals(1000) -> " + c.equals(d));
    }
}
