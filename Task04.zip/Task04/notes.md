# Task04: Classes, Objects and Constructors

Source: ConstructorDemo.java

Run: `javac *.java` then `java ConstructorDemo`

Result: Chaining with this(...) and a copy constructor that re-issues the same ticket number.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
