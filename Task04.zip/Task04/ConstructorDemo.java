public class ConstructorDemo {
    static class Ticket {
        private final int no; private final String regNo; private final int floor, slot;
        Ticket(int no, String regNo, int floor, int slot) { this.no = no; this.regNo = regNo; this.floor = floor; this.slot = slot; }
        Ticket(int no, String regNo) { this(no, regNo, -1, -1); }          // constructor chaining with this(...)
        Ticket(Ticket t) { this(t.no, t.regNo, t.floor, t.slot); }          // copy constructor: re-issued duplicate ticket
        @Override public String toString() { return "Ticket#" + no + "[" + regNo + " F" + floor + " S" + slot + "]"; }
    }
    public static void main(String[] args) {
        Ticket a = new Ticket(1, "TN01A1", 0, 0);
        Ticket b = new Ticket(2, "TN02B2");
        Ticket dup = new Ticket(a);
        System.out.println(a + "\n" + b + "\n" + dup + "\nsame object? " + (a == dup) + "  same number? true");
    }
}
