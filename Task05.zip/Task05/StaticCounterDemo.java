public class StaticCounterDemo {
    static class TicketStatic { private static int counter = 0; final int no = ++counter; }
    static class Facility {                                  // wrong design: instance counter
        private int counter = 0; int issue() { return ++counter; }
    }
    public static void main(String[] args) {
        Facility north = new Facility(), south = new Facility();
        System.out.println("Instance counters -> north ticket " + north.issue() + ", south ticket " + south.issue() + "  (both 1: NOT unique)");
        TicketStatic t1 = new TicketStatic(), t2 = new TicketStatic();
        System.out.println("Static counter    -> ticket " + t1.no + " and ticket " + t2.no + "  (unique across facilities)");
        TicketStatic t3 = new TicketStatic(); t3 = null; System.gc();   // t3 object is now unreachable -> eligible for GC
        System.out.println("After t3 = null the third ticket object is eligible for garbage collection.");
    }
}
