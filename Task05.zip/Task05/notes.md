# Task05: static Members and Object Life Cycle

Source: StaticCounterDemo.java

Run: `javac *.java` then `java StaticCounterDemo`

Result: An instance counter gives both facilities ticket 1; a static counter keeps ticket numbers unique.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
