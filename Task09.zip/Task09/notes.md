# Task09: Abstraction

Source: AbstractionDemo.java

Run: `javac *.java` then `java AbstractionDemo`

Result: Abstract class for shared state, interfaces for capabilities; default and static interface methods demonstrated.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
