import java.time.LocalDate;
public class AbstractionDemo {
    public static void main(String[] args) {
        Pass p = d -> d.equals(LocalDate.of(2026, 11, 9));
        LocalDate day = LocalDate.of(2026, 11, 9);
        System.out.println("valid on day: " + p.isValidOn(day) + ", expired on next day (default method): " + p.isExpired(day.plusDays(1)));
        System.out.println("Pass.none() valid? " + Pass.none().isValidOn(day) + "  (static interface method)");
        ElectricScooter s = new ElectricScooter();
        System.out.println("Multiple interfaces: charging fee 10 kWh = " + s.chargingFee(10) + ", pays " + s.payable());
    }
}
interface Pass {
    boolean isValidOn(LocalDate d);
    default boolean isExpired(LocalDate d) { return !isValidOn(d); }
    static Pass none() { return d -> false; }
}
interface Chargeable { double chargingFee(int kWh); }
interface Payable { boolean payable(); }
class ElectricScooter implements Chargeable, Payable {
    public double chargingFee(int kWh) { return kWh * 12.0; }
    public boolean payable() { return true; }
}
