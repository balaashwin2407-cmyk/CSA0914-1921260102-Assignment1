public class CastingDemo {
    public static void main(String[] args) {
        int minutes = 130; double rate = 30;
        System.out.println("Wrong  (minutes / 60) * rate          = " + (minutes / 60) * rate);
        System.out.println("Wrong  (double)(minutes / 60) * rate  = " + (double) (minutes / 60) * rate);
        System.out.println("Wrong  Math.ceil(minutes / 60) * rate = " + Math.ceil(minutes / 60) * rate);
        System.out.println("Right  (minutes + 59) / 60 * rate     = " + (minutes + 59) / 60 * rate);
        double fee = 12.75;
        System.out.println("(int) 12.75 = " + (int) fee + "  (paise lost by the cast)");
        int[] slotsPerFloor = {40, 60, 50, 80, 100};
        int[][] jag = new int[slotsPerFloor.length][];
        for (int f = 0; f < jag.length; f++) jag[f] = new int[slotsPerFloor[f]];
        System.out.println("Jagged array: floor 4 has " + jag[4].length + " slots, floor 0 has " + jag[0].length);
    }
}
