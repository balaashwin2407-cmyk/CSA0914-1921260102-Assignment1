# Task02: Choose the Data Representation

Source: CastingDemo.java

Run: `javac *.java` then `java CastingDemo`

Result: (130/60)*30 gives Rs 60 (wrong); (130+59)/60*30 gives Rs 90 (correct). Jagged array supports uneven floors.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
