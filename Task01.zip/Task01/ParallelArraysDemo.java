public class ParallelArraysDemo {
    static String[] regNo = {"TN01A1", "TN02B2", "TN03C3"};
    static String[] type = {"TwoWheeler", "Car", "EV"};
    static int[] entryMinute = {540, 555, 600};

    static int find(String r) {                       // O(n) scan, then index into the other arrays
        for (int i = 0; i < regNo.length; i++) if (regNo[i].equals(r)) return i;
        return -1;
    }
    static class VehicleRec {                         // object design: one place per attribute
        String regNo, type; int entryMinute;
        VehicleRec(String r, String t, int e) { regNo = r; type = t; entryMinute = e; }
    }
    public static void main(String[] args) {
        int i = find("TN02B2");
        System.out.println("Parallel arrays: index=" + i + " type=" + type[i] + " entry=" + entryMinute[i]);
        VehicleRec[] list = { new VehicleRec("TN01A1", "TwoWheeler", 540), new VehicleRec("TN02B2", "Car", 555) };
        for (VehicleRec v : list) if (v.regNo.equals("TN02B2")) System.out.println("Objects: type=" + v.type + " entry=" + v.entryMinute);
    }
}
