# Task01: Understand the Problem and Identify the Objects

Source: analysis only; ParallelArraysDemo.java shows the alternative

Run: `javac *.java` then `java ParallelArraysDemo`

Result: Candidate classes, business rules and assumptions are in the report. Parallel arrays and objects both find a vehicle in O(n); objects make adding an attribute a one-place change.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
