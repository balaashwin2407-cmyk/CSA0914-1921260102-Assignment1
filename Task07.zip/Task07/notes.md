# Task07: Override and Specialise Behaviour

Source: OverrideDemo.java

Run: `javac *.java` then `java OverrideDemo`

Result: Car and EV with the same plate are equal, have equal hash codes and collapse to one HashSet entry.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
