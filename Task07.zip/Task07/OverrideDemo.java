import java.util.*;
public class OverrideDemo {
    public static void main(String[] args) {
        Vehicle a = new Car("TN02B2"), b = new EV("TN02B2");
        System.out.println(a + " equals " + b + " -> " + a.equals(b));
        System.out.println("hash codes equal -> " + (a.hashCode() == b.hashCode()));
        Set<Vehicle> set = new HashSet<>(); set.add(a); set.add(b);
        System.out.println("HashSet size (duplicate plate counted once) -> " + set.size());
    }
}
abstract class Vehicle {
    private final String regNo;
    Vehicle(String r) { regNo = r; }
    @Override public boolean equals(Object o) { return o instanceof Vehicle && regNo.equals(((Vehicle) o).regNo); }
    @Override public int hashCode() { return regNo.hashCode(); }
    @Override public String toString() { return getClass().getSimpleName() + "[" + regNo + "]"; }
}
class Car extends Vehicle { Car(String r) { super(r); } }
class EV extends Car { EV(String r) { super(r); } }
