# Task03: Control Logic and Complete the Code

Source: ParkingFacility.java

Run: `javac *.java` then `java ParkingFacility`

Result: Output matches the expected output exactly: [0, 0] [0, 1] [1, 0] null / true false false / [0, 1].

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
