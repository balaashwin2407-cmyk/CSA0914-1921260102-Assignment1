# Task06: Inheritance Hierarchy

Source: ConstructorOrderDemo.java

Run: `javac *.java` then `java ConstructorOrderDemo`

Result: Constructor bodies run Vehicle, then Car, then ElectricCar. UML diagram is in the report.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
