public class ConstructorOrderDemo {
    public static void main(String[] args) {
        System.out.println("Creating ElectricCar...");
        new ElectricCar("TN03C3");
    }
}
class Vehicle { Vehicle(String r) { System.out.println("Vehicle constructor body  (regNo=" + r + ")"); } }
class Car extends Vehicle { Car(String r) { super(r); System.out.println("Car constructor body"); } }
class ElectricCar extends Car { ElectricCar(String r) { super(r); System.out.println("ElectricCar constructor body"); } }
