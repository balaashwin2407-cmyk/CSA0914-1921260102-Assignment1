# Task08: Polymorphism - Complete the Code (FeeDemo)

Source: FeeDemo.java

Run: `javac *.java` then `java FeeDemo`

Result: Output matches expected: Rs 30.0, Rs 90.0, Rs 210.0, true.

Output: see `expected_output.txt`; add your own screenshot in `screenshots/`.
